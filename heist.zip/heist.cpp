

#include "heist.h"



static int strLenPtr(const char* str) {
    if (!str) return 0;
    int len = 0;
    const char* p = str;
    while (*p != '\0') {
        ++len;
        ++p;
    }
    return len;
}


static void copyStrPtr(char*& dest, const char* src) {
    delete[] dest;
    dest = nullptr;
    if (!src) return;

    int len = strLenPtr(src);
    dest = new char[len + 1];

    char* d = dest;
    const char* s = src;
    while (*s != '\0') {
        *d = *s;
        ++d;
        ++s;
    }
    *d = '\0';
}


static void copyToBufPtr(char* dest, int maxLen, const char* src) {
    if (!dest || maxLen <= 0) return;
    char* d = dest;
    const char* s = src;
    int count = 0;
    if (s) {
        while (*s != '\0' && count < maxLen - 1) {
            *d = *s;
            ++d;
            ++s;
            ++count;
        }
    }
    *d = '\0';
}



Tile::Tile() : tileLetter('\0'), filled(false), boardPos(-1), tileRow(ROW_ONE) {}

Tile::Tile(char letter, int pos, WordRow row)
    : tileLetter(letter), filled(false), boardPos(pos), tileRow(row) {}

bool Tile::operator==(const Tile& other) const {
    return tileLetter == other.tileLetter;
}

bool Tile::operator==(char ch) const {
    return tileLetter == ch;
}

std::ostream& operator<<(std::ostream& os, const Tile& t) {
    os << (t.tileLetter != '\0' ? t.tileLetter : '_');
    return os;
}

std::istream& operator>>(std::istream& is, Tile& t) {
    int r = 0;
    is >> t.tileLetter >> t.filled >> t.boardPos >> r;
    t.tileRow = static_cast<WordRow>(r);
    return is;
}



Clue::Clue() : clueLetter('\0'), cluePosition(0), clueRow(ROW_ONE) {}

Clue::Clue(char letter, int pos, WordRow row)
    : clueLetter(letter), cluePosition(pos), clueRow(row) {}


Location::Location()
    : locName(nullptr), letterClueLoc('\0'), boardPosLoc(0),
      locRow(ROW_ONE), locSearchFlag(false) {}

Location::Location(const char* name, char letter, int pos, WordRow row)
    : locName(nullptr), letterClueLoc(letter), boardPosLoc(pos),
      locRow(row), locSearchFlag(false) {
    copyStrPtr(locName, name);
}

Location::Location(const Location& other)
    : locName(nullptr), letterClueLoc(other.letterClueLoc),
      boardPosLoc(other.boardPosLoc), locRow(other.locRow),
      locSearchFlag(other.locSearchFlag) {
    copyStrPtr(locName, other.locName);
}

Location& Location::operator=(const Location& other) {
    if (this != &other) {
        copyStrPtr(locName, other.locName);
        letterClueLoc = other.letterClueLoc;
        boardPosLoc   = other.boardPosLoc;
        locRow        = other.locRow;
        locSearchFlag = other.locSearchFlag;
    }
    return *this;
}

Location::~Location() {
    delete[] locName;
    locName = nullptr;
}

std::ostream& operator<<(std::ostream& os, const Location& l) {
    os << (l.locName ? l.locName : "Unknown Room")
       << (l.locSearchFlag ? " [SEARCHED]" : " [Unsearched]");
    return os;
}

std::istream& operator>>(std::istream& is, Location& l) {
    char buffer[256];
    is.getline(buffer, 256);
    copyStrPtr(l.locName, buffer);
    return is;
}



GameException::GameException(const char* msg) : message(nullptr) {
    copyStrPtr(message, msg);
}

GameException::GameException(const GameException& other) : message(nullptr) {
    copyStrPtr(message, other.message);
}

GameException::~GameException() {
    delete[] message;
    message = nullptr;
}

const char* GameException::what() const noexcept {
    return message ? message : "GameException";
}

InvalidWordException::InvalidWordException(const char* msg)
    : GameException(msg) {}

RackFullException::RackFullException(const char* msg)
    : GameException(msg) {}

InvalidPositionException::InvalidPositionException(const char* msg)
    : GameException(msg) {}



Character::Character()
    : charName(nullptr), charRole(nullptr), clueTile('\0'),
      cluePosition(0), clueRow(ROW_ONE), interviewed(false) {}

Character::Character(const char* name, const char* role, char tile, int pos, WordRow row)
    : charName(nullptr), charRole(nullptr), clueTile(tile),
      cluePosition(pos), clueRow(row), interviewed(false) {
    copyStrPtr(charName, name);
    copyStrPtr(charRole, role);
}

Character::Character(const Character& other)
    : charName(nullptr), charRole(nullptr), clueTile(other.clueTile),
      cluePosition(other.cluePosition), clueRow(other.clueRow),
      interviewed(other.interviewed) {
    copyStrPtr(charName, other.charName);
    copyStrPtr(charRole, other.charRole);
}

Character& Character::operator=(const Character& other) {
    if (this != &other) {
        copyStrPtr(charName, other.charName);
        copyStrPtr(charRole, other.charRole);
        clueTile     = other.clueTile;
        cluePosition = other.cluePosition;
        clueRow      = other.clueRow;
        interviewed  = other.interviewed;
    }
    return *this;
}

Character::~Character() {
    delete[] charName;
    delete[] charRole;
    charName = nullptr;
    charRole = nullptr;
}

const char* Character::getName()         const { return charName ? charName : "Unknown"; }
const char* Character::getRole()         const { return charRole ? charRole : "Unknown"; }
char        Character::getClueTile()     const { return clueTile; }
int         Character::getCluePosition() const { return cluePosition; }
WordRow     Character::getClueRow()      const { return clueRow; }
bool        Character::isInterviewed()   const { return interviewed; }

void Character::setInterviewed(bool val) { interviewed = val; }
void Character::setClueData(char tile, int pos, WordRow row) {
    clueTile     = tile;
    cluePosition = pos;
    clueRow      = row;
}

std::ostream& operator<<(std::ostream& os, const Character& c) {
    os << "[" << c.getType() << "] "
       << (c.charName ? c.charName : "Unknown")
       << " (" << (c.charRole ? c.charRole : "Unknown") << ")";
    return os;
}

std::istream& operator>>(std::istream& is, Character& c) {
    char buf[256];
    is.getline(buf, 256);
    copyStrPtr(c.charName, buf);
    return is;
}



Victim::Victim()
    : Character(), causeOfDeath(nullptr), lastKnownLocation(nullptr) {}

Victim::Victim(const char* name, const char* role, char tile, int pos, WordRow row,
               const char* cod, const char* lkl)
    : Character(name, role, tile, pos, row),
      causeOfDeath(nullptr), lastKnownLocation(nullptr) {
    copyStrPtr(causeOfDeath, cod);
    copyStrPtr(lastKnownLocation, lkl);
}

Victim::Victim(const Victim& other)
    : Character(other), causeOfDeath(nullptr), lastKnownLocation(nullptr) {
    copyStrPtr(causeOfDeath, other.causeOfDeath);
    copyStrPtr(lastKnownLocation, other.lastKnownLocation);
}

Victim& Victim::operator=(const Victim& other) {
    if (this != &other) {
        Character::operator=(other);
        copyStrPtr(causeOfDeath, other.causeOfDeath);
        copyStrPtr(lastKnownLocation, other.lastKnownLocation);
    }
    return *this;
}

Victim::~Victim() {
    delete[] causeOfDeath;
    delete[] lastKnownLocation;
    causeOfDeath = nullptr;
    lastKnownLocation = nullptr;
}

void Victim::display() const {
    std::cout << "\n  +---------------- VICTIM DOSSIER ----------------+\n";
    std::cout << "  Name           : " << (charName ? charName : "Unknown") << "\n";
    std::cout << "  Status         : DECEASED\n";
    std::cout << "  Title          : " << (charRole ? charRole : "Unknown") << "\n";
    std::cout << "  Cause of Death : " << (causeOfDeath ? causeOfDeath : "Unknown") << "\n";
    std::cout << "  Last Seen At   : " << (lastKnownLocation ? lastKnownLocation : "Unknown") << "\n";
    std::cout << "  +------------------------------------------------+\n";
}

const char* Victim::getType()              const { return "VICTIM"; }
const char* Victim::getCauseOfDeath()      const { return causeOfDeath; }
const char* Victim::getLastKnownLocation() const { return lastKnownLocation; }



Detective::Detective()
    : Character("Inspector Victor Reid", "Scotland Yard Chief Inspector", '\0', -1, ROW_ONE),
      credibility(100), turnsLeft(25), badgeNumber(nullptr) {
    copyStrPtr(badgeNumber, "SY-1923-VR");
}

Detective::Detective(const char* name, const char* role, const char* badge)
    : Character(name, role, '\0', -1, ROW_ONE),
      credibility(100), turnsLeft(25), badgeNumber(nullptr) {
    copyStrPtr(badgeNumber, badge);
}

Detective::Detective(const Detective& other)
    : Character(other), credibility(other.credibility),
      turnsLeft(other.turnsLeft), badgeNumber(nullptr) {
    copyStrPtr(badgeNumber, other.badgeNumber);
}

Detective& Detective::operator=(const Detective& other) {
    if (this != &other) {
        Character::operator=(other);
        credibility = other.credibility;
        turnsLeft   = other.turnsLeft;
        copyStrPtr(badgeNumber, other.badgeNumber);
    }
    return *this;
}

Detective::~Detective() {
    delete[] badgeNumber;
    badgeNumber = nullptr;
}

void Detective::display() const {
    std::cout << "\n  +-------------- DETECTIVE PROFILE ---------------+\n";
    std::cout << "  Name        : " << (charName ? charName : "Unknown") << "\n";
    std::cout << "  Badge       : " << (badgeNumber ? badgeNumber : "None") << "\n";
    std::cout << "  Credibility : " << credibility << " / 100\n";
    std::cout << "  Turns Left  : " << turnsLeft   << " / 25\n";
    std::cout << "  +------------------------------------------------+\n";
}

const char* Detective::getType()        const { return "DETECTIVE"; }
int         Detective::getCredibility() const { return credibility; }
int         Detective::getTurnsLeft()   const { return turnsLeft; }
bool        Detective::isAlive()        const { return (turnsLeft > 0 && credibility > 0); }

void Detective::deductTurn(int amount) {
    turnsLeft -= amount;
    if (turnsLeft < 0) turnsLeft = 0;
}

void Detective::deductCredibility(int amount) {
    credibility -= amount;
    if (credibility < 0) credibility = 0;
}

void Detective::addCredibility(int amount) {
    credibility += amount;
    if (credibility > 100) credibility = 100;
}

void Detective::reset() {
    credibility = 100;
    turnsLeft   = 25;
}



Suspect::Suspect()
    : Character(), isCulprit(false), motive(nullptr),
      alibi(nullptr), word1(nullptr), word2(nullptr) {}

Suspect::Suspect(const char* name, const char* role, char tile, int pos, WordRow row,
                 const char* mot, const char* ali, const char* w1, const char* w2)
    : Character(name, role, tile, pos, row), isCulprit(false),
      motive(nullptr), alibi(nullptr), word1(nullptr), word2(nullptr) {
    copyStrPtr(motive, mot);
    copyStrPtr(alibi,  ali);
    copyStrPtr(word1,  w1);
    copyStrPtr(word2,  w2);
}

Suspect::Suspect(const Suspect& other)
    : Character(other), isCulprit(other.isCulprit),
      motive(nullptr), alibi(nullptr), word1(nullptr), word2(nullptr) {
    copyStrPtr(motive, other.motive);
    copyStrPtr(alibi,  other.alibi);
    copyStrPtr(word1,  other.word1);
    copyStrPtr(word2,  other.word2);
}

Suspect& Suspect::operator=(const Suspect& other) {
    if (this != &other) {
        Character::operator=(other);
        isCulprit = other.isCulprit;
        copyStrPtr(motive, other.motive);
        copyStrPtr(alibi,  other.alibi);
        copyStrPtr(word1,  other.word1);
        copyStrPtr(word2,  other.word2);
    }
    return *this;
}

Suspect::~Suspect() {
    delete[] motive;
    delete[] alibi;
    delete[] word1;
    delete[] word2;
    motive = nullptr;
    alibi  = nullptr;
    word1  = nullptr;
    word2  = nullptr;
}

void Suspect::display() const {
    std::cout << "  Name   : " << (charName ? charName : "Unknown") << "\n";
    std::cout << "  Role   : " << (charRole ? charRole : "Unknown") << "\n";
    std::cout << "  Motive : " << (motive   ? motive   : "None documented") << "\n";
    std::cout << "  Alibi  : " << (alibi    ? alibi    : "Unverified") << "\n";
}

const char* Suspect::getType()                const { return "SUSPECT"; }
bool        Suspect::getIsCulprit()           const { return isCulprit; }
void        Suspect::setIsCulprit(bool val)         { isCulprit = val; }
const char* Suspect::getMotive()              const { return motive ? motive : "None documented"; }
const char* Suspect::getAlibi()               const { return alibi ? alibi : "Unverified"; }
const char* Suspect::getWord1()               const { return word1 ? word1 : "SCANDAL"; }
const char* Suspect::getWord2()               const { return word2 ? word2 : "EVIDENCE"; }
int         Suspect::getCredibilityRequired() const { return 40; }



BusinessRelations::BusinessRelations() : Suspect(), companyName(nullptr) {}

BusinessRelations::BusinessRelations(const char* name, const char* role,
                                     char tile, int pos, WordRow row,
                                     const char* mot, const char* ali,
                                     const char* w1, const char* w2,
                                     const char* company)
    : Suspect(name, role, tile, pos, row, mot, ali, w1, w2), companyName(nullptr) {
    copyStrPtr(companyName, company);
}

BusinessRelations::BusinessRelations(const BusinessRelations& other)
    : Suspect(other), companyName(nullptr) {
    copyStrPtr(companyName, other.companyName);
}

BusinessRelations& BusinessRelations::operator=(const BusinessRelations& other) {
    if (this != &other) {
        Suspect::operator=(other);
        copyStrPtr(companyName, other.companyName);
    }
    return *this;
}

BusinessRelations::~BusinessRelations() {
    delete[] companyName;
    companyName = nullptr;
}

void BusinessRelations::display() const {
    std::cout << "  Name         : " << (charName    ? charName    : "Unknown") << "\n";
    std::cout << "  Role         : " << (charRole    ? charRole    : "Unknown") << "\n";
    std::cout << "  Affiliation  : " << (companyName ? companyName : "None")    << "\n";
    std::cout << "  Motive       : " << (motive      ? motive      : "None")    << "\n";
    std::cout << "  Alibi        : " << (alibi       ? alibi       : "None")    << "\n";
}

const char* BusinessRelations::getType()                const { return "BUSINESS RELATION"; }
const char* BusinessRelations::getCompanyName()          const { return companyName; }
int         BusinessRelations::getCredibilityRequired() const { return 50; }



HouseHelp::HouseHelp() : Suspect(), yearsOfService(nullptr) {}

HouseHelp::HouseHelp(const char* name, const char* role,
                     char tile, int pos, WordRow row,
                     const char* mot, const char* ali,
                     const char* w1, const char* w2,
                     const char* years)
    : Suspect(name, role, tile, pos, row, mot, ali, w1, w2), yearsOfService(nullptr) {
    copyStrPtr(yearsOfService, years);
}

HouseHelp::HouseHelp(const HouseHelp& other)
    : Suspect(other), yearsOfService(nullptr) {
    copyStrPtr(yearsOfService, other.yearsOfService);
}

HouseHelp& HouseHelp::operator=(const HouseHelp& other) {
    if (this != &other) {
        Suspect::operator=(other);
        copyStrPtr(yearsOfService, other.yearsOfService);
    }
    return *this;
}

HouseHelp::~HouseHelp() {
    delete[] yearsOfService;
    yearsOfService = nullptr;
}

void HouseHelp::display() const {
    std::cout << "  Name             : " << (charName       ? charName       : "Unknown") << "\n";
    std::cout << "  Role             : " << (charRole       ? charRole       : "Unknown") << "\n";
    std::cout << "  Years of Service : " << (yearsOfService ? yearsOfService : "Unknown") << "\n";
    std::cout << "  Motive           : " << (motive         ? motive         : "None")    << "\n";
    std::cout << "  Alibi            : " << (alibi          ? alibi          : "None")    << "\n";
}

const char* HouseHelp::getType()                const { return "HOUSE HELP"; }
const char* HouseHelp::getYearsOfService()      const { return yearsOfService; }
int         HouseHelp::getCredibilityRequired() const { return 40; }



CloseRelations::CloseRelations() : Suspect(), relationship(nullptr) {}

CloseRelations::CloseRelations(const char* name, const char* role,
                               char tile, int pos, WordRow row,
                               const char* mot, const char* ali,
                               const char* w1, const char* w2,
                               const char* rel)
    : Suspect(name, role, tile, pos, row, mot, ali, w1, w2), relationship(nullptr) {
    copyStrPtr(relationship, rel);
}

CloseRelations::CloseRelations(const CloseRelations& other)
    : Suspect(other), relationship(nullptr) {
    copyStrPtr(relationship, other.relationship);
}

CloseRelations& CloseRelations::operator=(const CloseRelations& other) {
    if (this != &other) {
        Suspect::operator=(other);
        copyStrPtr(relationship, other.relationship);
    }
    return *this;
}

CloseRelations::~CloseRelations() {
    delete[] relationship;
    relationship = nullptr;
}

void CloseRelations::display() const {
    std::cout << "  Name         : " << (charName     ? charName     : "Unknown") << "\n";
    std::cout << "  Role         : " << (charRole     ? charRole     : "Unknown") << "\n";
    std::cout << "  Relationship : " << (relationship ? relationship : "Family")  << "\n";
    std::cout << "  Motive       : " << (motive       ? motive       : "None")    << "\n";
    std::cout << "  Alibi        : " << (alibi        ? alibi        : "None")    << "\n";
}

const char* CloseRelations::getType()                const { return "CLOSE RELATION"; }
const char* CloseRelations::getRelationship()         const { return relationship; }
int         CloseRelations::getCredibilityRequired() const { return 60; }



PA::PA()
    : Suspect(), BusinessRelations(), CloseRelations(), securityClearance(nullptr) {}

PA::PA(const char* name, const char* role,
       char tile, int pos, WordRow row,
       const char* mot, const char* ali,
       const char* w1, const char* w2,
       const char* company, const char* rel,
       const char* clearance)
    : Suspect(name, role, tile, pos, row, mot, ali, w1, w2),
      BusinessRelations(name, role, tile, pos, row, mot, ali, w1, w2, company),
      CloseRelations   (name, role, tile, pos, row, mot, ali, w1, w2, rel),
      securityClearance(nullptr) {
    copyStrPtr(securityClearance, clearance);
}

PA::PA(const PA& other)
    : Suspect(other), BusinessRelations(other), CloseRelations(other),
      securityClearance(nullptr) {
    copyStrPtr(securityClearance, other.securityClearance);
}

PA& PA::operator=(const PA& other) {
    if (this != &other) {
        BusinessRelations::operator=(other);
       
        copyStrPtr(relationship, other.getRelationship());
        copyStrPtr(securityClearance, other.securityClearance);
    }
    return *this;
}

PA::~PA() {
    delete[] securityClearance;
    securityClearance = nullptr;
}

void PA::display() const {
    std::cout << "  Name               : " << (charName          ? charName          : "Unknown") << "\n";
    std::cout << "  Role               : " << (charRole          ? charRole          : "Unknown") << "\n";
    std::cout << "  Affiliation        : " << (companyName       ? companyName       : "None")    << "\n";
    std::cout << "  Relationship       : " << (relationship      ? relationship      : "None")    << "\n";
    std::cout << "  Security Clearance : " << (securityClearance ? securityClearance : "Standard") << "\n";
    std::cout << "  Motive             : " << (motive            ? motive            : "None")    << "\n";
    std::cout << "  Alibi              : " << (alibi             ? alibi             : "None")    << "\n";
}

const char* PA::getType()                const { return "PERSONAL ASSISTANT"; }
const char* PA::getSecurityClearance()   const { return securityClearance; }
int         PA::getCredibilityRequired() const { return 35; }




TileRack::TileRack() : rack(MAX_SIZE) {}
TileRack::TileRack(const TileRack& other) : rack(other.rack) {}
TileRack& TileRack::operator=(const TileRack& other) {
    if (this != &other) {
        rack = other.rack;
    }
    return *this;
}
TileRack::~TileRack() {}

void TileRack::addTile(const Tile& tile) {
    if (rack.getSize() >= MAX_SIZE) {
        throw RackFullException("Evidence Tile Rack is at maximum capacity (15 tiles).");
    }
    rack.add(tile);
}

Tile TileRack::removeTileAt(int index) {
    Tile item = rack.get(index);
    rack.removeAt(index);
    return item;
}

int   TileRack::getSize()  const { return rack.getSize(); }
bool  TileRack::isFull()   const { return rack.getSize() >= MAX_SIZE; }
bool  TileRack::isEmpty()  const { return rack.isEmpty(); }
Tile* TileRack::getAt(int index) const { return rack.getPtr(index); }

Tile* TileRack::rackBegin() const { return rack.begin(); }
Tile* TileRack::rackEnd()   const { return rack.end(); }

void TileRack::displayRack() const {
    std::cout << "  Tile Rack (" << rack.getSize() << "/" << MAX_SIZE << ") : ";
    if (rack.isEmpty()) {
        std::cout << "[Empty]\n";
        return;
    }

    for (Tile* p = rack.begin(); p != rack.end(); ++p) {
        std::cout << "[" << p->tileLetter
                  << " R" << (p->tileRow == ROW_ONE ? 1 : 2)
                  << " P" << (p->boardPos + 1) << "] ";
    }
    std::cout << "\n";
}

TileRack TileRack::operator+(const TileRack& other) const {
    TileRack merged;
    for (Tile* p = rack.begin(); p != rack.end(); ++p) {
        merged.addTile(*p);
    }
    for (Tile* p = other.rack.begin(); p != other.rack.end(); ++p) {
        if (!merged.isFull()) {
            merged.addTile(*p);
        }
    }
    return merged;
}



Scrabble::Scrabble() : board(2), goalWord1(nullptr), goalWord2(nullptr) {
    
    DynamicArray<Tile> row1(7);
    for (int i = 0; i < 7; ++i) {
        Tile blankTile('\0', i, ROW_ONE);
        row1.add(blankTile);
    }
    board.add(row1);

    DynamicArray<Tile> row2(8);
    for (int i = 0; i < 8; ++i) {
        Tile blankTile('\0', i, ROW_TWO);
        row2.add(blankTile);
    }
    board.add(row2);
}

Scrabble::Scrabble(const Scrabble& other)
    : board(other.board), goalWord1(nullptr), goalWord2(nullptr) {
    copyStrPtr(goalWord1, other.goalWord1);
    copyStrPtr(goalWord2, other.goalWord2);
}

Scrabble& Scrabble::operator=(const Scrabble& other) {
    if (this != &other) {
        board = other.board;
        copyStrPtr(goalWord1, other.goalWord1);
        copyStrPtr(goalWord2, other.goalWord2);
    }
    return *this;
}

Scrabble::~Scrabble() {
    delete[] goalWord1;
    delete[] goalWord2;
    goalWord1 = nullptr;
    goalWord2 = nullptr;
}

void Scrabble::setGoalWords(const char* w1, const char* w2) {
    copyStrPtr(goalWord1, w1);
    copyStrPtr(goalWord2, w2);
}

bool Scrabble::placeTile(const Tile& tile, int row, int pos) {
    if (row < 0 || row >= board.getSize()) {
        throw InvalidPositionException("Invalid Scrabble board row coordinate.");
    }
    DynamicArray<Tile>* rPtr = board.getPtr(row);
    if (pos < 0 || pos >= rPtr->getSize()) {
        throw InvalidPositionException("Invalid Scrabble board column position index.");
    }

    Tile* target = rPtr->begin() + pos;
    target->tileLetter = tile.tileLetter;
    target->filled     = true;
    target->boardPos   = pos;
    target->tileRow    = static_cast<WordRow>(row);
    return true;
}

bool Scrabble::isRowComplete(int row) const {
    if (row < 0 || row >= board.getSize()) return false;
    const DynamicArray<Tile>* rPtr = board.getPtr(row);

    for (Tile* p = rPtr->begin(); p != rPtr->end(); ++p) {
        if (!p->filled) return false;
    }
    return true;
}

bool Scrabble::isBoardComplete() const {
    return isRowComplete(0) && isRowComplete(1);
}

bool Scrabble::checkWord(int row) const {
    if (!isRowComplete(row)) return false;
    const char* goal = (row == 0) ? goalWord1 : goalWord2;
    if (!goal) return false;

    const DynamicArray<Tile>* rPtr = board.getPtr(row);
    Tile* p = rPtr->begin();
    Tile* endPtr = rPtr->end();
    const char* g = goal;

    while (p != endPtr && *g != '\0') {
        if (p->tileLetter != *g) return false;
        ++p;
        ++g;
    }
    return (p == endPtr && *g == '\0');
}

bool Scrabble::checkAllWords() const {
    return checkWord(0) && checkWord(1);
}

void Scrabble::clearRow(int row) {
    if (row < 0 || row >= board.getSize()) return;
    DynamicArray<Tile>* rPtr = board.getPtr(row);
    for (Tile* p = rPtr->begin(); p != rPtr->end(); ++p) {
        p->tileLetter = '\0';
        p->filled     = false;
    }
}

void Scrabble::resetBoard() {
    clearRow(0);
    clearRow(1);
}

void Scrabble::displayBoard() const {
    std::cout << "\n  +================== SCRABBLE BOARD ==================+\n";
    for (int r = 0; r < board.getSize(); ++r) {
        const DynamicArray<Tile>* rPtr = board.getPtr(r);
        std::cout << "  | Row " << (r + 1) << " (" << rPtr->getSize() << " letters): | ";
        for (Tile* p = rPtr->begin(); p != rPtr->end(); ++p) {
            std::cout << (p->filled ? p->tileLetter : '_') << " | ";
        }
        std::cout << "\n";
    }
    std::cout << "  +====================================================+\n";
}

int Scrabble::getRowSize(int row) const {
    if (row < 0 || row >= board.getSize()) return 0;
    return board.getPtr(row)->getSize();
}

const char* Scrabble::getGoalWord1() const { return goalWord1; }
const char* Scrabble::getGoalWord2() const { return goalWord2; }

std::ostream& operator<<(std::ostream& os, const Scrabble& b) {
    b.displayBoard();
    return os;
}

std::istream& operator>>(std::istream& is, Scrabble& b) {
    char w1[64], w2[64];
    if (is >> w1 >> w2) {
        b.setGoalWords(w1, w2);
    }
    return is;
}


Cottage::Cottage() : locations(NUM_LOCATIONS) {}
Cottage::Cottage(const Cottage& other) : locations(other.locations) {}
Cottage& Cottage::operator=(const Cottage& other) {
    if (this != &other) {
        locations = other.locations;
    }
    return *this;
}
Cottage::~Cottage() {}

void Cottage::addLocation(const Location& loc) {
    locations.add(loc);
}

Location* Cottage::getLocation(int index) const {
    if (index < 0 || index >= locations.getSize()) return nullptr;
    return locations.getPtr(index);
}

int Cottage::getNumLocations() const {
    return locations.getSize();
}

void Cottage::displayLocations() const {
    int idx = 1;
    for (Location* p = locations.begin(); p != locations.end(); ++p) {
        std::cout << "  [" << idx << "] " << *p << "\n";
        ++idx;
    }
}

Location* Cottage::locBegin() const { return locations.begin(); }
Location* Cottage::locEnd()   const { return locations.end(); }

void Cottage::setup(const char* const names[], const char* word, WordRow row) {
    locations.clear();


    char fileNames[NUM_LOCATIONS][128];
    int fileCount = 0;
    std::ifstream locFile("data/locations.txt");
    if (!locFile.is_open()) locFile.open("locations.txt");

    if (locFile.is_open()) {
        char buf[128];
        while (fileCount < NUM_LOCATIONS && locFile.getline(buf, 128)) {
            if (strLenPtr(buf) > 0) {
                char* dst = *(fileNames + fileCount);
                const char* src = buf;
                while (*src != '\0') {
                    *dst = *src;
                    ++dst;
                    ++src;
                }
                *dst = '\0';
                ++fileCount;
            }
        }
        locFile.close();
    }

    const char* lp = word;
    int pos = 0;
    while (*lp != '\0' && pos < NUM_LOCATIONS) {
        const char* nameToUse = (fileCount == NUM_LOCATIONS) ? *(fileNames + pos) : *(names + pos);
        Location loc(nameToUse, *lp, pos, row);
        locations.add(loc);
        ++lp;
        ++pos;
    }
}

void Cottage::clearLocations() {
    locations.clear();
}


GameEngine* GameEngine::instance = nullptr;

GameEngine::GameEngine()
    : state(MAIN_MENU), detective(nullptr), victim(nullptr),
      suspects(nullptr), numSuspects(7), culpritIndex(0),
      word1Formed(false), word2Formed(false), gameActive(false) {
    detective = new Detective();
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
}

GameEngine::~GameEngine() {
    delete detective;
    delete victim;
    detective = nullptr;
    victim    = nullptr;
    deleteSuspects();
    instance = nullptr;
}

GameEngine& GameEngine::getInstance() {
    if (!instance) {
        instance = new GameEngine();
    }
    return *instance;
}

void GameEngine::deleteSuspects() {
    if (suspects) {
        Suspect** p = suspects;
        Suspect** endPtr = suspects + numSuspects;
        while (p != endPtr) {
            delete *p;
            *p = nullptr;
            ++p;
        }
        delete[] suspects;
        suspects = nullptr;
    }
}

void GameEngine::extractField(const char* line, int fieldIdx, char* dest, int maxLen) {
    int cur = 0;
    const char* p = line;
    while (*p != '\0' && cur < fieldIdx) {
        if (*p == '|') ++cur;
        ++p;
    }
    int i = 0;
    while (*p != '\0' && *p != '|' && *p != '\r' && *p != '\n' && i < maxLen - 1) {
        *(dest + i) = *p;
        ++p;
        ++i;
    }
    *(dest + i) = '\0';
}

void GameEngine::loadCharactersFromFile() {
    deleteSuspects();
    suspects = new Suspect*[numSuspects];
    for (int i = 0; i < numSuspects; ++i) {
        *(suspects + i) = nullptr;
    }

    
    static const char* dNames[] = {
        "Margaret Holt", "Thomas Crane", "Clara Fenn",
        "James Booth", "Lady Evelyn Ashton", "Father Patrick Lorne", "Roland Cross"
    };
    static const char* dRoles[] = {
        "Business Partner", "Estate Lawyer", "Head Housekeeper",
        "Butler", "Wife & Heiress", "Brother-in-law", "Personal Assistant"
    };
    static const char* dMotives[] = {
        "Financial embezzlement from joint company accounts",
        "Concealing fraudulent modifications to the estate will",
        "Retaliation for abrupt termination without severance",
        "Blackmail extortion regarding stolen family heirlooms",
        "Collecting substantial life insurance and estate inheritance",
        "Bitterness over disputed family property settlements",
        "Access to the private security safe combination"
    };
    static const char* dAlibis[] = {
        "Attending the city charity gala all evening",
        "Reviewing corporate contracts in London",
        "Supervising dinner preparation in the manor kitchen",
        "Polishing silverware in the dining pantry",
        "At the theatre in the company of close acquaintances",
        "Holding evening vespers at the parish church",
        "Organizing confidential documents in the private study"
    };
    static const char* dW1[] = {"SCANDAL","MYSTERY","FORGERY","SILENCE","KIDNAPS","TRICKED","PENSION"};
    static const char* dW2[] = {"EVIDENCE","BETRAYAL","DARKNESS","CRIMINAL","LOCKPICK","LOCKDOWN","DEFRAUDS"};
    static const char* dE1[] = {
        "Holt Industries", "Crane Legal Associates",
        "12 years of service", "8 years of service",
        "Spouse", "Brother-in-law", "Ashton Enterprises"
    };
    static const int dTypes[] = {0, 0, 1, 1, 2, 2, 3};

    std::ifstream file("data/characters.txt");
    if (!file.is_open()) file.open("characters.txt");
    bool useFile = file.is_open();

    int idx = 0;
    while (idx < numSuspects) {
        char name[256] = {}, role[256] = {}, mot[512] = {}, ali[512] = {};
        char w1[32] = {}, w2[32] = {}, ts[8] = {}, ex1[256] = {}, ex2[256] = {};
        int typeCode = *(dTypes + idx);

        if (useFile) {
            char line[1024] = {};
            if (file.getline(line, 1024)) {
                extractField(line, 0, name, 256);
                extractField(line, 1, role, 256);
                extractField(line, 2, mot, 512);
                extractField(line, 3, ali, 512);
                extractField(line, 4, w1, 32);
                extractField(line, 5, w2, 32);
                extractField(line, 6, ts, 8);
                extractField(line, 7, ex1, 256);
                extractField(line, 8, ex2, 256);
                if (*ts >= '0' && *ts <= '3') {
                    typeCode = *ts - '0';
                }
            } else {
                useFile = false;
            }
        }

        
        if (!useFile || strLenPtr(name) == 0) {
            copyToBufPtr(name, 256, *(dNames + idx));
            copyToBufPtr(role, 256, *(dRoles + idx));
            copyToBufPtr(mot,  512, *(dMotives + idx));
            copyToBufPtr(ali,  512, *(dAlibis + idx));
            copyToBufPtr(w1,   32,  *(dW1 + idx));
            copyToBufPtr(w2,   32,  *(dW2 + idx));
            copyToBufPtr(ex1,  256, *(dE1 + idx));
            typeCode = *(dTypes + idx);
        }

        Suspect* s = nullptr;
        if (typeCode == 0) {
            s = new BusinessRelations(name, role, '\0', -1, ROW_TWO, mot, ali, w1, w2, ex1);
        } else if (typeCode == 1) {
            s = new HouseHelp(name, role, '\0', -1, ROW_TWO, mot, ali, w1, w2, ex1);
        } else if (typeCode == 2) {
            s = new CloseRelations(name, role, '\0', -1, ROW_TWO, mot, ali, w1, w2, ex1);
        } else {
            s = new PA(name, role, '\0', -1, ROW_TWO, mot, ali, w1, w2, ex1, ex2, "LEVEL-3 CLEARANCE");
        }

        *(suspects + idx) = s;
        ++idx;
    }
    if (file.is_open()) file.close();

   
    culpritIndex = std::rand() % numSuspects;
    (*(suspects + culpritIndex))->setIsCulprit(true);
}

void GameEngine::setupVictim() {
    delete victim;
    victim = new Victim(
        "Lord Edmund Ashton", "Estate Owner & Industrialist",
        '\0', -1, ROW_TWO,
        "Blunt force trauma to the cranium",
        "The Locked Study - Slumped over his mahogany desk"
    );
}

void GameEngine::distributeClues() {
    Suspect* cul = *(suspects + culpritIndex);
    const char* w1 = cul->getWord1();
    const char* w2 = cul->getWord2();

    scrabble.resetBoard();
    scrabble.setGoalWords(w1, w2);

    
    static const char* locNames[] = {
        "The Library", "The Study", "The Kitchen",
        "The Cellar", "The Garden", "The Garage", "The Master Bedroom"
    };
    cottage.setup(locNames, w1, ROW_ONE);

    
    const char* lp = w2;
    victim->setClueData(*lp, 0, ROW_TWO);
    ++lp;

    Suspect** sp = suspects;
    Suspect** se = suspects + numSuspects;
    int pos = 1;
    while (sp != se) {
        (*sp)->setClueData(*lp, pos, ROW_TWO);
        ++sp;
        ++lp;
        ++pos;
    }

    
    victim->setInterviewed(false);
    sp = suspects;
    while (sp != se) {
        (*sp)->setInterviewed(false);
        ++sp;
    }
    for (Location* lc = cottage.locBegin(); lc != cottage.locEnd(); ++lc) {
        lc->locSearchFlag = false;
    }

    playerRack  = TileRack();
    word1Formed = false;
    word2Formed = false;

   
    std::ofstream cf("data/clue.txt");
    if (!cf.is_open()) cf.open("clue.txt");
    if (cf.is_open()) {
        cf << "========================================================\n";
        cf << "        THE LOCKER HEIST - CASE EVIDENCE LEDGER         \n";
        cf << "========================================================\n";
        cf << "Row 1 Word (" << strLenPtr(w1) << " letters) : " << w1 << "\n";
        cf << "Row 2 Word (" << strLenPtr(w2) << " letters) : " << w2 << "\n\n";
        cf << "[Location Letter Clues - Row 1]\n";
        for (Location* lc = cottage.locBegin(); lc != cottage.locEnd(); ++lc) {
            cf << "Location: " << (lc->locName ? lc->locName : "Unknown")
               << " -> Letter: " << lc->letterClueLoc
               << " (Position " << (lc->boardPosLoc + 1) << ")\n";
        }
        cf << "\n[Character Letter Clues - Row 2]\n";
        cf << "Victim: " << victim->getName()
           << " -> Letter: " << victim->getClueTile()
           << " (Position " << (victim->getCluePosition() + 1) << ")\n";
        for (Suspect** sp_it = suspects; sp_it != suspects + numSuspects; ++sp_it) {
            cf << "Suspect: " << (*sp_it)->getName()
               << " -> Letter: " << (*sp_it)->getClueTile()
               << " (Position " << ((*sp_it)->getCluePosition() + 1) << ")\n";
        }
        cf << "========================================================\n";
        cf.close();
    }
}

void GameEngine::saveScoreToFile(bool won) {
    std::time_t now = std::time(nullptr);
    struct tm ti;
    localtime_s(&ti, &now);

    char dateStr[64];
    snprintf(dateStr, sizeof(dateStr), "%04d-%02d-%02d %02d:%02d:%02d",
             ti.tm_year + 1900, ti.tm_mon + 1, ti.tm_mday,
             ti.tm_hour, ti.tm_min, ti.tm_sec);

    const char* resultStr = won ? "WIN " : "LOSS";

    
    std::ofstream fLeader("leader/scoreBoard.txt", std::ios::app);
    if (fLeader.is_open()) {
        fLeader << resultStr
                << " | Credibility: " << detective->getCredibility()
                << " | Turns used: "  << (25 - detective->getTurnsLeft())
                << " | Date: "        << dateStr << "\n";
        fLeader.close();
    }

    std::ofstream fData("data/scoreBoard.txt", std::ios::app);
    if (fData.is_open()) {
        fData << resultStr
              << " | Credibility: " << detective->getCredibility()
              << " | Turns used: "  << (25 - detective->getTurnsLeft())
              << " | Date: "        << dateStr << "\n";
        fData.close();
    }
}



void GameEngine::displayDivider(char ch, int width) const {
    std::cout << "  ";
    for (int i = 0; i < width; ++i) std::cout << ch;
    std::cout << "\n";
}

void GameEngine::displayCentered(const char* text, int width) const {
    if (!text) return;
    int len = strLenPtr(text);
    int pad = (width - len) / 2;
    std::cout << "  ";
    for (int i = 0; i < pad; ++i) std::cout << ' ';
    std::cout << text << "\n";
}

void GameEngine::displayTitle() const {
    std::cout << "\n";
    displayDivider('#', 65);
    displayCentered("T H E   L O C K E R   H E I S T", 65);
    displayCentered("A 1923 Scotland Yard Detective Mystery", 65);
    displayDivider('#', 65);
    std::cout << "\n";
}

void GameEngine::clearConsole() const {
#ifdef _WIN32
    system("cls");
#else
    std::cout << "\033[2J\033[1;1H";
#endif
}

void GameEngine::pauseForUser() const {
    std::cout << "\n  [Press ENTER to continue...]";
    std::cin.ignore(10000, '\n');
    std::cin.get();
}

int GameEngine::getIntInput(int minVal, int maxVal) const {
    int val = -1;
    while (true) {
        std::cin >> val;
        if (std::cin.fail() || val < minVal || val > maxVal) {
            std::cin.clear();
            std::cin.ignore(10000, '\n');
            std::cout << "  [!] Please enter a valid number (" << minVal << " - " << maxVal << "): ";
        } else {
            std::cin.ignore(10000, '\n');
            return val;
        }
    }
}

void GameEngine::displayMainMenu() const {
    clearConsole();
    displayTitle();
    displayDivider('-', 65);
    displayCentered("M A I N   M E N U", 65);
    displayDivider('-', 65);
    std::cout << "\n";
    std::cout << "    [1] New Game\n";
    std::cout << "    [2] Leader / Score Board\n";
    std::cout << "    [3] About The Case\n";
    std::cout << "    [4] Investigation Rules\n";
    std::cout << "    [5] Exit Game\n";
    std::cout << "\n";
    displayDivider('-', 65);
    std::cout << "  Select an option (1-5): ";
}

void GameEngine::displayGameMenu() const {
    std::cout << "\n";
    displayDivider('-', 65);
    displayCentered("INVESTIGATION ACTIONS", 65);
    displayDivider('-', 65);
    std::cout << "    [1] Visit a Location          (Costs 1 Turn)\n";
    std::cout << "    [2] Interview a Person        (Costs 1 Turn)\n";
    std::cout << "    [3] View Scrabble Board       (FREE - Costs 0 Turns)\n";
    std::cout << "    [4] Form a Word on the Board  (Costs 1 Turn)\n";
    std::cout << "    [5] Accuse a Suspect          (Costs 1 Turn)\n";
    std::cout << "    [6] Quit to Main Menu\n";
    displayDivider('-', 65);
    std::cout << "  Select action (1-6): ";
}

void GameEngine::displayStatusBar() const {
    displayDivider('=', 65);
    std::cout << "  CREDIBILITY: " << std::setw(3) << detective->getCredibility()
              << "/100 | TURNS LEFT: " << std::setw(2) << detective->getTurnsLeft()
              << " | Word 1: " << (word1Formed ? "[SOLVED]" : "_______")
              << " | Word 2: " << (word2Formed ? "[SOLVED]" : "________") << "\n";
    displayDivider('=', 65);
}



void GameEngine::handleVisitLocation() {
    clearConsole();
    displayDivider();
    displayCentered("INVESTIGATE MANOR LOCATION");
    displayDivider();
    std::cout << "\n  Select a room to search:\n\n";
    cottage.displayLocations();
    std::cout << "\n  Enter location number (1-" << cottage.getNumLocations() << "): ";
    int choice = getIntInput(1, cottage.getNumLocations());

    Location* loc = cottage.getLocation(choice - 1);
    if (!loc) return;

    std::cout << "\n  Searching " << loc->locName << "...\n\n";

    
    if (loc->locSearchFlag) {
        std::cout << "  [REVISIT NOTE] You have already searched this room.\n";
        std::cout << "  Previously discovered letter : [ " << loc->letterClueLoc
                  << " ] (Row 1, Position " << (loc->boardPosLoc + 1) << ")\n";
        std::cout << "  No turns deducted for this revisit.\n";
    } else {
        loc->locSearchFlag = true;
        detective->deductTurn(1);
        std::cout << "  Success! Behind a hidden fixture you find a carved letter tile:\n";
        std::cout << "  ===> [ " << loc->letterClueLoc << " ] "
                  << "(Target: Row 1, Position " << (loc->boardPosLoc + 1) << ")\n";

        Tile t(loc->letterClueLoc, loc->boardPosLoc, ROW_ONE);
        try {
            playerRack.addTile(t);
        } catch (const RackFullException& e) {
            std::cout << "  [Warning]: " << e.what() << "\n";
        }

        scrabble.placeTile(t, 0, loc->boardPosLoc);
        std::cout << "  The letter has been placed into your evidence rack & Scrabble board.\n";
        std::cout << "  Turns remaining: " << detective->getTurnsLeft() << "\n";
    }
    pauseForUser();
}

void GameEngine::handleInterviewCharacter() {
    clearConsole();
    displayDivider();
    displayCentered("INTERROGATE WITNESS OR SUSPECT");
    displayDivider();
    std::cout << "\n  Select an individual to interrogate:\n\n";

    std::cout << "  [1] " << victim->getName() << " (Victim Post-Mortem)"
              << " [Req: 80 Credibility]"
              << (victim->isInterviewed() ? " [EXAMINED]" : "") << "\n";

    int idx = 2;
    for (Suspect** sp = suspects; sp != suspects + numSuspects; ++sp) {
        std::cout << "  [" << idx << "] " << (*sp)->getName()
                  << " (" << (*sp)->getType() << ")"
                  << " [Req: " << (*sp)->getCredibilityRequired() << " Credibility]"
                  << ((*sp)->isInterviewed() ? " [INTERVIEWED]" : "") << "\n";
        ++idx;
    }

    std::cout << "\n  Enter person number (1-" << (numSuspects + 1) << "): ";
    int choice = getIntInput(1, numSuspects + 1);

    if (choice == 1) {
      
        if (detective->getCredibility() < 80) {
            std::cout << "\n  [ACCESS DENIED] The coroner refuses you access to the body!\n";
            std::cout << "  Examining Lord Ashton requires at least 80 credibility.\n";
            std::cout << "  Current Credibility: " << detective->getCredibility() << "\n";
            detective->deductCredibility(5);
            std::cout << "  Penalty: -5 Credibility (Now " << detective->getCredibility() << ")\n";
            pauseForUser();
            return;
        }

        victim->display();
        if (victim->isInterviewed()) {
            std::cout << "\n  [REVISIT NOTE] You have already examined the body.\n";
            std::cout << "  Previously noted cufflink letter: [ " << victim->getClueTile()
                      << " ] (Row 2, Position " << (victim->getCluePosition() + 1) << ")\n";
            std::cout << "  No turns deducted.\n";
        } else {
            victim->setInterviewed(true);
            detective->deductTurn(1);
            std::cout << "\n  During autopsy, you discover a hidden monogrammed cufflink engraved with:\n";
            std::cout << "  ===> [ " << victim->getClueTile() << " ] "
                      << "(Target: Row 2, Position " << (victim->getCluePosition() + 1) << ")\n";

            Tile t(victim->getClueTile(), victim->getCluePosition(), ROW_TWO);
            try {
                playerRack.addTile(t);
            } catch (const RackFullException& e) {
                std::cout << "  [Warning]: " << e.what() << "\n";
            }
            scrabble.placeTile(t, 1, victim->getCluePosition());
            std::cout << "  Turns remaining: " << detective->getTurnsLeft() << "\n";
        }
    } else {
        int sIdx = choice - 2;
        Suspect* s = *(suspects + sIdx);

        int reqCred = s->getCredibilityRequired();
        if (detective->getCredibility() < reqCred) {
            std::cout << "\n  [INTERVIEW REBUFFED] " << s->getName() << " refuses to speak with you!\n";
            std::cout << "  Interrogating this person requires at least " << reqCred << " credibility.\n";
            std::cout << "  Current Credibility: " << detective->getCredibility() << "\n";
            detective->deductCredibility(5);
            std::cout << "  Penalty: -5 Credibility (Now " << detective->getCredibility() << ")\n";
            pauseForUser();
            return;
        }

        std::cout << "\n";
        s->display();

        if (s->isInterviewed()) {
            std::cout << "\n  [REVISIT NOTE] You have already questioned " << s->getName() << ".\n";
            std::cout << "  Previously observed letter: [ " << s->getClueTile()
                      << " ] (Row 2, Position " << (s->getCluePosition() + 1) << ")\n";
            std::cout << "  No turns deducted.\n";
        } else {
            s->setInterviewed(true);
            detective->deductTurn(1);
            std::cout << "\n  Under rigorous questioning, you press for evidence and recover a letter tile:\n";
            std::cout << "  ===> [ " << s->getClueTile() << " ] "
                      << "(Target: Row 2, Position " << (s->getCluePosition() + 1) << ")\n";

            Tile t(s->getClueTile(), s->getCluePosition(), ROW_TWO);
            try {
                playerRack.addTile(t);
            } catch (const RackFullException& e) {
                std::cout << "  [Warning]: " << e.what() << "\n";
            }
            scrabble.placeTile(t, 1, s->getCluePosition());
            std::cout << "  Turns remaining: " << detective->getTurnsLeft() << "\n";
        }
    }
    pauseForUser();
}

void GameEngine::handleViewBoard() const {
    clearConsole();
    displayDivider();
    displayCentered("EVIDENCE & SCRABBLE BOARD");
    displayDivider();
    scrabble.displayBoard();
    playerRack.displayRack();
    std::cout << "\n  [Note]: Reviewing evidence board costs 0 turns.\n";
    const_cast<GameEngine*>(this)->pauseForUser();
}

void GameEngine::handleFormWord() {
    clearConsole();
    displayDivider();
    displayCentered("FORM SECRET WORD");
    displayDivider();
    scrabble.displayBoard();

    std::cout << "\n  Select row to form and validate:\n";
    std::cout << "    [1] Row 1 (7-Letter Word from Locations)\n";
    std::cout << "    [2] Row 2 (8-Letter Word from Characters)\n";
    std::cout << "  Your choice (1-2): ";
    int choice = getIntInput(1, 2);
    int boardRow = choice - 1;

    if (boardRow == 0 && word1Formed) {
        std::cout << "\n  Row 1 is already successfully solved: [ " << scrabble.getGoalWord1() << " ]\n";
        pauseForUser();
        return;
    }
    if (boardRow == 1 && word2Formed) {
        std::cout << "\n  Row 2 is already successfully solved: [ " << scrabble.getGoalWord2() << " ]\n";
        pauseForUser();
        return;
    }

    if (!scrabble.isRowComplete(boardRow)) {
        std::cout << "\n  [INCOMPLETE EVIDENCE] Row " << choice << " does not have all letter tiles!\n";
        std::cout << "  Premature word attempt penalty: -10 Credibility, -1 Turn.\n";
        detective->deductCredibility(10);
        detective->deductTurn(1);
        pauseForUser();
        return;
    }

    detective->deductTurn(1);
    if (scrabble.checkWord(boardRow)) {
        const char* solvedWord = (boardRow == 0) ? scrabble.getGoalWord1() : scrabble.getGoalWord2();
        std::cout << "\n  *** SUCCESS! Row " << choice << " correctly spells: [ " << solvedWord << " ] ***\n";
        if (boardRow == 0) word1Formed = true;
        else               word2Formed = true;

        if (word1Formed && word2Formed) {
            std::cout << "\n  Both secret words are completely solved!\n";
            std::cout << "  You now possess the cipher to unmask the culprit!\n";
        }
    } else {
        std::cout << "\n  [ERROR] Tiles placed do not match the required secret word.\n";
        std::cout << "  Penalty: -10 Credibility.\n";
        detective->deductCredibility(10);
        throw InvalidWordException("Attempted word formation did not validate against target cipher.");
    }
    pauseForUser();
}

void GameEngine::handleAccuse() {
    clearConsole();
    displayDivider();
    displayCentered("ACCUSE THE CULPRIT");
    displayDivider();

    if (!word1Formed || !word2Formed) {
        std::cout << "\n  [CANNOT ACCUSE YET] You must solve BOTH words on the Scrabble board\n";
        std::cout << "  before the Crown Prosecutor will accept a formal accusation!\n";
        std::cout << "  Word 1 Status: " << (word1Formed ? "SOLVED" : "INCOMPLETE") << "\n";
        std::cout << "  Word 2 Status: " << (word2Formed ? "SOLVED" : "INCOMPLETE") << "\n";
        pauseForUser();
        return;
    }

    std::cout << "\n  Suspect List:\n\n";
    int idx = 1;
    for (Suspect** p = suspects; p != suspects + numSuspects; ++p) {
        std::cout << "  [" << idx << "] " << (*p)->getName() << " (" << (*p)->getRole() << ")\n";
        ++idx;
    }

    std::cout << "\n  Who murdered Lord Ashton and looted the safe? (1-" << numSuspects << "): ";
    int choice = getIntInput(1, numSuspects);
    Suspect* accused = *(suspects + (choice - 1));

    detective->deductTurn(1);

    if (accused->getIsCulprit()) {
        std::cout << "\n  =======================================================\n";
        std::cout << "                  *** CASE SOLVED! ***                   \n";
        std::cout << "  =======================================================\n";
        std::cout << "  " << accused->getName() << " drops to their knees in full confession!\n";
        std::cout << "  \"Yes! I stole the combination: "
                  << scrabble.getGoalWord1() << " and " << scrabble.getGoalWord2()
                  << " -- and Lord Ashton caught me in the act!\"\n";
        state      = GAME_WON;
        gameActive = false;
        endGame(true);
    } else {
        std::cout << "\n  [FALSE ACCUSATION!] " << accused->getName() << " has a rock-solid alibi!\n";
        std::cout << "  Scotland Yard's reputation is severely damaged. Penalty: -20 Credibility.\n";
        detective->deductCredibility(20);
        std::cout << "  Current Credibility: " << detective->getCredibility() << "\n";

        if (detective->getCredibility() <= 0) {
            std::cout << "  Your credibility has collapsed entirely.\n";
            state      = GAME_LOST;
            gameActive = false;
        }
    }
    pauseForUser();
}

void GameEngine::checkGameOverConditions() {
    if (state == GAME_WON || state == GAME_LOST) return;

    if (!detective->isAlive()) {
        if (detective->getTurnsLeft() <= 0) {
            std::cout << "\n  [TIME EXPIRED] You have exhausted all 25 turns! The culprit fled abroad.\n";
        } else {
            std::cout << "\n  [DISGRACED] Your credibility dropped to 0! You are stripped of your badge.\n";
        }
        state      = GAME_LOST;
        gameActive = false;
        endGame(false);
    }
}



void GameEngine::run() {
    bool running = true;
    while (running) {
        displayMainMenu();
        int choice = getIntInput(1, 5);
        switch (choice) {
            case NEW_GAME:    startNewGame();    break;
            case LEADERBOARD: showLeaderboard(); break;
            case ABOUT:       showAbout();       break;
            case RULES:       showRules();       break;
            case EXIT_GAME:   running = false;   break;
        }
    }

    clearConsole();
    displayTitle();
    std::cout << "  Thank you for playing The Locker Heist. Goodbye, Inspector.\n\n";
}

void GameEngine::startNewGame() {
    clearConsole();
    displayDivider();
    displayCentered("INITIALIZING ASHTON MANOR CASE FILE");
    displayDivider();

    loadCharactersFromFile();
    setupVictim();
    distributeClues();
    detective->reset();

    state      = GAME_RUNNING;
    gameActive = true;

    std::cout << "\n  Case File successfully registered.\n";
    std::cout << "  - Lord Edmund Ashton found dead in his study.\n";
    std::cout << "  - 7 Manor locations ready for forensic sweep.\n";
    std::cout << "  - 7 Suspects detained for questioning.\n";
    std::cout << "  - Starting Credibility: 100 | Turns Allowed: 25\n";
    pauseForUser();

    while (gameActive && detective->isAlive() && state == GAME_RUNNING) {
        clearConsole();
        displayStatusBar();
        displayGameMenu();
        int choice = getIntInput(1, 6);

        try {
            switch (choice) {
                case 1: handleVisitLocation();      break;
                case 2: handleInterviewCharacter(); break;
                case 3: handleViewBoard();          break;
                case 4: handleFormWord();           break;
                case 5: handleAccuse();             break;
                case 6:
                    gameActive = false;
                    state      = MAIN_MENU;
                    std::cout << "\n  Investigation suspended. Returning to Main Menu...\n";
                    pauseForUser();
                    break;
            }
        }
        catch (const InvalidWordException& e) {
            std::cout << "\n  [Game Exception]: " << e.what() << "\n";
            pauseForUser();
        }
        catch (const RackFullException& e) {
            std::cout << "\n  [Game Exception]: " << e.what() << "\n";
            pauseForUser();
        }
        catch (const InvalidPositionException& e) {
            std::cout << "\n  [Game Exception]: " << e.what() << "\n";
            pauseForUser();
        }
        catch (const GameException& e) {
            std::cout << "\n  [Game Exception]: " << e.what() << "\n";
            pauseForUser();
        }

        checkGameOverConditions();
    }
}

void GameEngine::endGame(bool won) {
    clearConsole();
    displayDivider('#', 65);
    if (won) {
        displayCentered("*** CASE CLOSED - VICTORY ***", 65);
    } else {
        displayCentered("*** CASE UNSOLVED - DEFEAT ***", 65);
    }
    displayDivider('#', 65);

    std::cout << "\n  Detective : " << detective->getName() << "\n";
    std::cout << "  Turns Expended    : " << (25 - detective->getTurnsLeft()) << " / 25\n";
    std::cout << "  Credibility Score : " << detective->getCredibility() << " / 100\n\n";

    Suspect* cul = *(suspects + culpritIndex);
    if (won) {
        std::cout << "  Culprit Identified : " << cul->getName() << " (" << cul->getRole() << ")\n";
        std::cout << "  Target Words       : " << scrabble.getGoalWord1()
                  << " & " << scrabble.getGoalWord2() << "\n";
    } else {
        std::cout << "  The True Culprit Was: " << cul->getName() << " (" << cul->getRole() << ")\n";
        std::cout << "  Target Words Were   : " << (scrabble.getGoalWord1() ? scrabble.getGoalWord1() : "UNKNOWN")
                  << " & " << (scrabble.getGoalWord2() ? scrabble.getGoalWord2() : "UNKNOWN") << "\n";
    }

    saveScoreToFile(won);
    displayDivider('#', 65);
    pauseForUser();
    state = MAIN_MENU;
}

void GameEngine::showLeaderboard() {
    clearConsole();
    displayDivider();
    displayCentered("LEADER / SCORE BOARD");
    displayDivider();

    std::ifstream f("leader/scoreBoard.txt");
    if (!f.is_open()) f.open("data/scoreBoard.txt");
    if (!f.is_open()) f.open("scoreBoard.txt");

    if (!f.is_open() || f.peek() == std::ifstream::traits_type::eof()) {
        std::cout << "\n  No previous investigations on record.\n";
    } else {
        char line[512];
        int row = 1;
        while (f.getline(line, 512)) {
            std::cout << "  " << std::setw(2) << row << ". " << line << "\n";
            ++row;
        }
        f.close();
    }
    displayDivider();
    pauseForUser();
}

void GameEngine::showAbout() {
    clearConsole();
    displayDivider();
    displayCentered("ABOUT THE LOCKER HEIST");
    displayDivider();

    std::ifstream f("data/about.txt");
    if (!f.is_open()) f.open("about.txt");

    if (f.is_open()) {
        char line[512];
        while (f.getline(line, 512)) {
            std::cout << "  " << line << "\n";
        }
        f.close();
    } else {
        std::cout << "\n  The Locker Heist (1923)\n";
        std::cout << "  A rich Object-Oriented C++ detective murder mystery set in Ashton Manor.\n";
        std::cout << "  Designed with pure pointer arithmetic, custom DMA, and zero STL containers.\n";
    }
    displayDivider();
    pauseForUser();
}

void GameEngine::showRules() {
    clearConsole();
    displayDivider();
    displayCentered("INVESTIGATION RULES");
    displayDivider();

    std::ifstream f("data/rules.txt");
    if (!f.is_open()) f.open("rules.txt");

    if (f.is_open()) {
        char line[512];
        while (f.getline(line, 512)) {
            std::cout << "  " << line << "\n";
        }
        f.close();
    } else {
        std::cout << "\n  OBJECTIVE  : Recover 15 letter tiles, solve both secret words,\n";
        std::cout << "               and accuse the correct culprit.\n";
        std::cout << "  TURNS      : 25 turns total. Actions cost 1 turn (Viewing board is FREE).\n";
        std::cout << "  CREDIBILITY: 100 points initial. Rebuffed interviews: -5 cred.\n";
        std::cout << "               Premature word attempts: -10 cred. Wrong accusation: -20 cred.\n";
        std::cout << "  THRESHOLDS : Victim >= 80 | CloseRel >= 60 | BusinessRel >= 50 | HouseHelp >= 40 | PA >= 35\n";
    }
    displayDivider();
    pauseForUser();
}

GameState GameEngine::getState() const {
    return state;
}
