
#ifndef HEIST_H
#define HEIST_H

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <stdexcept>
#include <iomanip>



enum GameState {
    MAIN_MENU,    
    GAME_RUNNING,   
    GAME_WON,       
    GAME_LOST       
};


enum MenuChoice {
    NEW_GAME    = 1,
    LEADERBOARD = 2,
    ABOUT       = 3,
    RULES       = 4,
    EXIT_GAME   = 5
};

enum WordRow {
    ROW_ONE,    
    ROW_TWO    
};




class GameEngine;


struct Tile {
    char    tileLetter;     
    bool    filled;        
    int     boardPos;       
    WordRow tileRow;       

    Tile();
    Tile(char letter, int pos, WordRow row);

   
    bool operator==(const Tile& other) const;
    bool operator==(char ch) const;

   
    friend std::ostream& operator<<(std::ostream& os, const Tile& t);
    friend std::istream& operator>>(std::istream& is, Tile& t);
};


struct Clue {
    char    clueLetter;     
    int     cluePosition;   
    WordRow clueRow;       

    Clue();
    Clue(char letter, int pos, WordRow row);
};


struct Location {
    char*   locName;        
    char    letterClueLoc;  
    int     boardPosLoc;   
    WordRow locRow;         
    bool    locSearchFlag;  

    Location();
    Location(const char* name, char letter, int pos, WordRow row);
    Location(const Location& other);
    Location& operator=(const Location& other);
    ~Location();

    friend std::ostream& operator<<(std::ostream& os, const Location& l);
    friend std::istream& operator>>(std::istream& is, Location& l);
};



template <typename T>
class DynamicArray {
private:
    T*  data;       
    int capacity;   
    int size;       

    
    void resize() {
        int newCap = (capacity < 4) ? 4 : capacity * 2;
        T*  newData = new T[newCap];

        T* src = data;
        T* dst = newData;
        T* end = data + size;
        while (src != end) {
            *dst = *src;
            ++src;
            ++dst;
        }

        delete[] data;
        data = newData;
        capacity = newCap;
    }

public:
    DynamicArray() : data(nullptr), capacity(0), size(0) {}

    explicit DynamicArray(int initialCapacity) : data(nullptr), capacity(0), size(0) {
        if (initialCapacity > 0) {
            data = new T[initialCapacity];
            capacity = initialCapacity;
        }
    }

    
    DynamicArray(const DynamicArray<T>& other) : data(nullptr), capacity(0), size(0) {
        if (other.size > 0) {
            data = new T[other.capacity];
            capacity = other.capacity;
            size = other.size;

            T* src = other.data;
            T* dst = data;
            T* end = other.data + other.size;
            while (src != end) {
                *dst = *src;
                ++src;
                ++dst;
            }
        }
    }

  
    DynamicArray<T>& operator=(const DynamicArray<T>& other) {
        if (this != &other) {
            delete[] data;
            data = nullptr;
            capacity = 0;
            size = 0;

            if (other.size > 0) {
                data = new T[other.capacity];
                capacity = other.capacity;
                size = other.size;

                T* src = other.data;
                T* dst = data;
                T* end = other.data + other.size;
                while (src != end) {
                    *dst = *src;
                    ++src;
                    ++dst;
                }
            }
        }
        return *this;
    }

    
    ~DynamicArray() {
        delete[] data;
        data = nullptr;
        capacity = 0;
        size = 0;
    }

    
    void add(const T& item) {
        if (size >= capacity) {
            resize();
        }
        *(data + size) = item;
        ++size;
    }

  
    T& get(int index) const {
        return *(data + index);
    }

  
    T* getPtr(int index) const {
        return (data + index);
    }

 
    void set(int index, const T& item) {
        *(data + index) = item;
    }

   
    void removeAt(int index) {
        if (index < 0 || index >= size) return;
        T* current = data + index;
        T* nextElem = current + 1;
        T* endPtr = data + size;
        while (nextElem != endPtr) {
            *current = *nextElem;
            ++current;
            ++nextElem;
        }
        --size;
    }

    int  getSize()     const { return size; }
    int  getCapacity() const { return capacity; }
    bool isEmpty()     const { return size == 0; }
    void clear()             { size = 0; }

    
    T* begin() const { return data; }
    T* end()   const { return data + size; }
};




class GameException : public std::exception {
protected:
    char* message; 
public:
    explicit GameException(const char* msg);
    GameException(const GameException& other);
    virtual ~GameException();
    virtual const char* what() const noexcept override;
};


class InvalidWordException : public GameException {
public:
    explicit InvalidWordException(const char* msg);
};


class RackFullException : public GameException {
public:
    explicit RackFullException(const char* msg);
};


class InvalidPositionException : public GameException {
public:
    explicit InvalidPositionException(const char* msg);
};

class Character {
protected:
    char*   charName;    
    char*   charRole;       
    char    clueTile;       
    int     cluePosition;   
    WordRow clueRow;        
    bool    interviewed;    

    friend class GameEngine;

public:
    Character();
    Character(const char* name, const char* role, char tile, int pos, WordRow row);
    Character(const Character& other);
    Character& operator=(const Character& other);
    virtual ~Character();

    // Pure virtual functions enforcing polymorphism
    virtual void        display() const = 0;
    virtual const char* getType() const = 0;

    const char* getName()         const;
    const char* getRole()         const;
    char        getClueTile()     const;
    int         getCluePosition() const;
    WordRow     getClueRow()      const;
    bool        isInterviewed()   const;

    void setInterviewed(bool val);
    void setClueData(char tile, int pos, WordRow row);

    // Stream operator overloading using friend functions
    friend std::ostream& operator<<(std::ostream& os, const Character& c);
    friend std::istream& operator>>(std::istream& is, Character& c);
};

/// The Victim: Lord Edmund Ashton (Deceased)
class Victim : public Character {
private:
    char* causeOfDeath;
    char* lastKnownLocation;
public:
    Victim();
    Victim(const char* name, const char* role, char tile, int pos, WordRow row,
           const char* cod, const char* lkl);
    Victim(const Victim& other);
    Victim& operator=(const Victim& other);
    virtual ~Victim();

    virtual void        display() const override;
    virtual const char* getType() const override;

    const char* getCauseOfDeath()      const;
    const char* getLastKnownLocation() const;
};

/// The Detective: Inspector Victor Reid (Player)
class Detective : public Character {
private:
    int   credibility;  ///< Credibility meter (0-100)
    int   turnsLeft;    ///< Turns remaining (Starts at 25)
    char* badgeNumber;
public:
    Detective();
    Detective(const char* name, const char* role, const char* badge);
    Detective(const Detective& other);
    Detective& operator=(const Detective& other);
    virtual ~Detective();

    virtual void        display() const override;
    virtual const char* getType() const override;

    int  getCredibility() const;
    int  getTurnsLeft()   const;
    bool isAlive()        const;

    void deductTurn(int amount = 1);
    void deductCredibility(int amount);
    void addCredibility(int amount);
    void reset();
};

/// Base Class for all suspects (virtually inherited by BusinessRelations and CloseRelations)
class Suspect : public Character {
protected:
    bool  isCulprit;    ///< True if this suspect is the actual thief/murderer
    char* motive;       ///< Suspect's suspected motive
    char* alibi;        ///< Suspect's claimed alibi
    char* word1;        ///< 7-letter secret word associated with culprit
    char* word2;        ///< 8-letter secret word associated with culprit
public:
    Suspect();
    Suspect(const char* name, const char* role, char tile, int pos, WordRow row,
            const char* mot, const char* ali, const char* w1, const char* w2);
    Suspect(const Suspect& other);
    Suspect& operator=(const Suspect& other);
    virtual ~Suspect();

    virtual void        display() const override;
    virtual const char* getType() const override;

    bool        getIsCulprit()  const;
    void        setIsCulprit(bool val);
    const char* getMotive()     const;
    const char* getAlibi()      const;
    const char* getWord1()      const;
    const char* getWord2()      const;

    virtual int getCredibilityRequired() const;
};

/// Suspect Branch 1: Business Partners & Legal Associates
/// Virtually inherits Suspect
class BusinessRelations : public virtual Suspect {
protected:
    char* companyName;
public:
    BusinessRelations();
    BusinessRelations(const char* name, const char* role, char tile, int pos, WordRow row,
                      const char* mot, const char* ali, const char* w1, const char* w2,
                      const char* company);
    BusinessRelations(const BusinessRelations& other);
    BusinessRelations& operator=(const BusinessRelations& other);
    virtual ~BusinessRelations();

    virtual void        display() const override;
    virtual const char* getType() const override;
    const char*         getCompanyName() const;
    virtual int         getCredibilityRequired() const override; // Requires 50
};

/// Suspect Branch 2: Domestic Estate Staff
class HouseHelp : public Suspect {
protected:
    char* yearsOfService;
public:
    HouseHelp();
    HouseHelp(const char* name, const char* role, char tile, int pos, WordRow row,
              const char* mot, const char* ali, const char* w1, const char* w2,
              const char* years);
    HouseHelp(const HouseHelp& other);
    HouseHelp& operator=(const HouseHelp& other);
    virtual ~HouseHelp();

    virtual void        display() const override;
    virtual const char* getType() const override;
    const char*         getYearsOfService() const;
    virtual int         getCredibilityRequired() const override; // Requires 40
};

/// Suspect Branch 3: Relatives & Close Personal Friends
/// Virtually inherits Suspect
class CloseRelations : public virtual Suspect {
protected:
    char* relationship;
public:
    CloseRelations();
    CloseRelations(const char* name, const char* role, char tile, int pos, WordRow row,
                   const char* mot, const char* ali, const char* w1, const char* w2,
                   const char* rel);
    CloseRelations(const CloseRelations& other);
    CloseRelations& operator=(const CloseRelations& other);
    virtual ~CloseRelations();

    virtual void        display() const override;
    virtual const char* getType() const override;
    const char*         getRelationship() const;
    virtual int         getCredibilityRequired() const override; // Requires 60
};

/// The Diamond Problem Solved via Virtual Inheritance:
/// PA inherits from both BusinessRelations and CloseRelations.
/// Virtual inheritance of Suspect guarantees only ONE instance of Suspect exists.
class PA : public BusinessRelations, public CloseRelations {
private:
    char* securityClearance;
public:
    PA();
    PA(const char* name, const char* role, char tile, int pos, WordRow row,
       const char* mot, const char* ali, const char* w1, const char* w2,
       const char* company, const char* rel, const char* clearance);
    PA(const PA& other);
    PA& operator=(const PA& other);
    virtual ~PA();

    virtual void        display() const override;
    virtual const char* getType() const override;
    const char*         getSecurityClearance() const;
    virtual int         getCredibilityRequired() const override; // Requires 35
};

// ============================================================================
// PHASE 1 & 2: BOARDS & DMA (REFACTORED WITH DynamicArray<T>)
// ============================================================================

/// Manages the detective's evidence tile collection.
/// Refactored to utilize DynamicArray<Tile>.
class TileRack {
private:
    DynamicArray<Tile> rack;
    static const int   MAX_SIZE = 15;
public:
    TileRack();
    TileRack(const TileRack& other);
    TileRack& operator=(const TileRack& other);
    ~TileRack();

    void  addTile(const Tile& tile);
    Tile  removeTileAt(int index);
    int   getSize()  const;
    bool  isFull()   const;
    bool  isEmpty()  const;
    Tile* getAt(int index) const;
    void  displayRack() const;

    Tile* rackBegin() const;
    Tile* rackEnd()   const;

    // Operator Overloading: Merge two racks
    TileRack operator+(const TileRack& other) const;
};

/// Represents the jagged 2D Scrabble Board.
/// Row 1 has 7 slots; Row 2 has 8 slots.
/// Refactored to utilize DynamicArray<DynamicArray<Tile>> with pointer arithmetic.
class Scrabble {
private:
    DynamicArray<DynamicArray<Tile>> board; ///< Jagged 2D dynamic array
    char* goalWord1;                        ///< 7-letter word target
    char* goalWord2;                        ///< 8-letter word target

public:
    Scrabble();
    Scrabble(const Scrabble& other);
    Scrabble& operator=(const Scrabble& other);
    ~Scrabble();

    void setGoalWords(const char* w1, const char* w2);
    bool placeTile(const Tile& tile, int row, int pos);
    bool isRowComplete(int row) const;
    bool isBoardComplete() const;
    bool checkWord(int row) const;
    bool checkAllWords() const;
    void clearRow(int row);
    void resetBoard();
    void displayBoard() const;

    int         getRowSize(int row) const;
    const char* getGoalWord1()      const;
    const char* getGoalWord2()      const;

    // Stream operator overloading using friend functions
    friend std::ostream& operator<<(std::ostream& os, const Scrabble& b);
    friend std::istream& operator>>(std::istream& is, Scrabble& b);
};

/// Manages the 7 investigatable areas of Ashton Manor.
/// Refactored to utilize DynamicArray<Location>.
class Cottage {
private:
    DynamicArray<Location> locations;
    static const int NUM_LOCATIONS = 7;
public:
    Cottage();
    Cottage(const Cottage& other);
    Cottage& operator=(const Cottage& other);
    ~Cottage();

    void      addLocation(const Location& loc);
    Location* getLocation(int index) const;
    int       getNumLocations() const;
    void      displayLocations() const;

    Location* locBegin() const;
    Location* locEnd()   const;

    void setup(const char* const names[], const char* word, WordRow row);
    void clearLocations();
};

// ============================================================================
// PHASE 3 & 4: SINGLETON GAME ENGINE
// ============================================================================
// Central controller orchestrating all OOP relationships:
//   Composition : Owns Detective, Cottage, Scrabble, TileRack
//   Aggregation : Cottage aggregates Location objects
//   Association : GameEngine communicates with file leaderboard
// Singleton Pattern: One global instance accessible via getInstance()
// ============================================================================
class GameEngine {
private:
    static GameEngine* instance;

    GameState   state;
    Detective*  detective;       ///< Composed
    Victim*     victim;          ///< Composed
    Suspect**   suspects;        ///< Polymorphic dynamic array of 7 suspects
    int         numSuspects;
    int         culpritIndex;

    Cottage     cottage;         ///< Composed
    Scrabble    scrabble;        ///< Composed
    TileRack    playerRack;      ///< Composed

    bool        word1Formed;
    bool        word2Formed;
    bool        gameActive;

    // Singleton: Private Constructor
    GameEngine();

    // Internal initialization and file helpers
    void loadCharactersFromFile();
    void setupVictim();
    void distributeClues();
    void saveScoreToFile(bool won);

    // Console presentation helpers
    void displayDivider(char ch = '=', int width = 65) const;
    void displayCentered(const char* text, int width = 65) const;
    void displayTitle() const;
    void clearConsole() const;
    void pauseForUser() const;
    int  getIntInput(int minVal, int maxVal) const;

    // Menu handlers
    void displayMainMenu()  const;
    void displayGameMenu()  const;
    void displayStatusBar() const;

    // Investigation action handlers
    void handleVisitLocation();
    void handleInterviewCharacter();
    void handleViewBoard()  const;
    void handleFormWord();
    void handleAccuse();
    void checkGameOverConditions();
    void deleteSuspects();

    static void extractField(const char* line, int fieldIdx, char* dest, int maxLen);

public:
    // Singleton: Prevent cloning and assignment
    GameEngine(const GameEngine&)            = delete;
    GameEngine& operator=(const GameEngine&) = delete;

    static GameEngine& getInstance();
    ~GameEngine();

    void run();
    void startNewGame();
    void showLeaderboard();
    void showAbout();
    void showRules();
    void endGame(bool won);

    GameState getState() const;
};

#endif // HEIST_H
